<?php 
include('header.php');
?>
    <!--Container Main start-->
    <div class="height-100 ">
        <div class="pt-4 row text-center">
            <div class="col-2 col-xl-2 col-md-3 dashboard-col">
                <h1> 12 </h1>
                <p> Total Posts </p>
</div>
                <div class="col-2 col-xl-2 col-md-3 dashboard-col">
                <h1> 12 </h1>
                <p> Total News </p>
</div>
                <div class="col-2 col-xl-2 col-md-3 dashboard-col">
                <h1> 12 </h1>
                <p> Total Companies </p>
</div>
<div class="col-2 col-xl-2 col-md-3 dashboard-col">
                <h1> 12 </h1>
                <p> Total Comments </p>
</div>
<div class="col-2 col-xl-2 col-md-3 dashboard-col">
                <h1> 12 </h1>
                <p> Total Contact Us </p>
</div>
</div>
    </div>
    <!--Container Main end-->
<?php 
include('footer.php');
?>