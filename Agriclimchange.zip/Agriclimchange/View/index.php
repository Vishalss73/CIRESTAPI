<?php 

include('component/header.php');
?>
<section class="homepage">
	<div class="homepage-container">
		<div class="page-header-ui-content position-relative">
                            <div class="container home-txt px-5">
                                <div class="row gx-5 justify-content-center">
                                    <div class="col-xl-10 col-lg-10 text-center">

                              <h1 class="pb-2 page-header-ui-title">We Launch Agriculture Study and Knowledge Resource </h1>

                                        <p class="page-header-ui-text mb-4">We Provide Agriculture Website, Companies, Product Details and Agri Study Resources. </p>
                                    </div></div>
                                
                                <div class="row gx-5 justify-content-center">
                                    <div class="col-xl-8 col-lg-8 text-center">
                                        <form class="row m-input row-cols-1 row-cols-md-auto align-items-center form-design">
                                            <div class="col   flex-grow-1">
                                                <input class="form-control form-input form-control-solid" id="inputEmail" type="text" placeholder="Search Jobs, Companies and Study Material">
                                            </div>
                                            <div class="col col-search"><button class="search-btn btn btn-teal fw-500" type="submit">Search</button></div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
</div>
</section>

<section class="containerss Sites-details">
  <div class="title-sites ">
    <h1> Agriculture Companies </h1>
    <p>know about the Agriculture Companies Get in depth information about companies.

</p>
  </div>
  <div class="row">
    <div class="mb-2 col-md-2 col-xl-2 col-sm-6 col-6">
     <div class="company-show-container sitesshow-container">
       <div class="img-show">
      <img src="assets/images/godrej.jpg">
     </div> 
     <div class="mt-2 title-col-company">
     
    </div>

  </div>
</div>
<div class="mb-2 col-md-2 col-sm-6 col-6">
     <div class="company-show-container sitesshow-container">
       <div class="img-show">
      <img src="assets/images/godrej.jpg">
     </div> 
     <div class="mt-2 title-col-company">
    
    </div>

  </div>
</div>
<div class="mb-2 col-md-2 col-sm-6 col-6">
     <div class="company-show-container sitesshow-container">
       <div class="img-show">
      <img src="assets/images/godrej.jpg">
     </div> 
     <div class="mt-2 title-col-company">
    
    </div>

  </div>
</div>
<div class="mb-2 col-md-2 col-sm-6 col-6">
     <div class="company-show-container sitesshow-container">
       <div class="img-show">
      <img src="assets/images/godrej.jpg">
     </div> 
     <div class="mt-2 title-col-company">
    
    </div>

  </div>
</div><div class="mb-2 col-md-2 col-sm-6 col-6">
     <div class="company-show-container sitesshow-container">
       <div class="img-show">
      <img src="assets/images/godrej.jpg">
     </div> 
     <div class="mt-2 title-col-company">
    
    </div>

  </div>
</div><div class="mb-2 col-md-2 col-sm-6 col-6">
     <div class="company-show-container sitesshow-container">
       <div class="img-show">
      <img src="assets/images/godrej.jpg">
     </div> 
     <div class="mt-2 title-col-company">
    
    </div>

  </div>
</div><div class="mb-2 col-md-2 col-sm-6 col-6">
     <div class="company-show-container sitesshow-container">
       <div class="img-show">
      <img src="assets/images/godrej.jpg">
     </div> 
     <div class="mt-2 title-col-company">
    
    </div>

  </div>
</div><div class="mb-2 col-md-2 col-sm-6 col-6">
     <div class="company-show-container sitesshow-container">
       <div class="img-show">
      <img src="assets/images/godrej.jpg">
     </div> 
     <div class="mt-2 title-col-company">
    
    </div>

  </div>
</div><div class="mb-2 col-md-2 col-sm-6 col-6">
     <div class="company-show-container sitesshow-container">
       <div class="img-show">
      <img src="assets/images/godrej.jpg">
     </div> 
     <div class="mt-2 title-col-company">
    
    </div>

  </div>
</div><div class="mb-2 col-md-2 col-sm-6 col-6">
     <div class="company-show-container sitesshow-container">
       <div class="img-show">
      <img src="assets/images/godrej.jpg">
     </div> 
     <div class="mt-2 title-col-company">
    
    </div>

  </div>
</div><div class="mb-2 col-md-2 col-sm-6 col-6">
     <div class="company-show-container sitesshow-container">
       <div class="img-show">
      <img src="assets/images/godrej.jpg">
     </div> 
     <div class="mt-2 title-col-company">
    
    </div>

  </div>
</div><div class="mb-2 col-md-2 col-sm-6 col-6">
     <div class="company-show-container sitesshow-container">
       <div class="img-show">
      <img src="assets/images/godrej.jpg">
     </div> 
     <div class="mt-2 title-col-company">
    
    </div>

  </div>
</div><div class="mb-2 col-md-2 col-sm-6 col-6">
     <div class="company-show-container sitesshow-container">
       <div class="img-show">
      <img src="assets/images/godrej.jpg">
     </div> 
     <div class="mt-2 title-col-company">
    
    </div>

  </div>
</div><div class="mb-2 col-md-2 col-sm-6 col-6">
     <div class="company-show-container sitesshow-container">
       <div class="img-show">
      <img src="assets/images/godrej.jpg">
     </div> 
     <div class="mt-2 title-col-company">
    
    </div>

  </div>
</div><div class="mb-2 col-md-2 col-sm-6 col-6">
     <div class="company-show-container sitesshow-container">
       <div class="img-show">
      <img src="assets/images/godrej.jpg">
     </div> 
     <div class="mt-2 title-col-company">
    
    </div>

  </div>
</div><div class="mb-2 col-md-2 col-sm-6 col-6">
     <div class="company-show-container sitesshow-container">
       <div class="img-show">
      <img src="assets/images/godrej.jpg">
     </div> 
     <div class="mt-2 title-col-company">
    
    </div>

  </div>
</div><div class="mb-2 col-md-2 col-sm-6 col-6">
     <div class="company-show-container sitesshow-container">
       <div class="img-show">
      <img src="assets/images/godrej.jpg">
     </div> 
     <div class="mt-2 title-col-company">
    
    </div>

  </div>
</div><div class="mb-2 col-md-2 col-sm-6 col-6">
     <div class="company-show-container sitesshow-container">
       <div class="img-show">
      <img src="assets/images/godrej.jpg">
     </div> 
     <div class="mt-2 title-col-company">
    
    </div>

  </div>
</div><div class="mb-2 col-md-2 col-sm-6 col-6">
     <div class="company-show-container sitesshow-container">
       <div class="img-show">
      <img src="assets/images/godrej.jpg">
     </div> 
     <div class="mt-2 title-col-company">
    
    </div>

  </div>
</div><div class="mb-2 col-md-2 col-sm-6 col-6">
     <div class="company-show-container sitesshow-container">
       <div class="img-show">
      <img src="assets/images/godrej.jpg">
     </div> 
     <div class="mt-2 title-col-company">
    
    </div>

  </div>
</div><div class="mb-2 col-md-2 col-sm-6 col-6">
     <div class="company-show-container sitesshow-container">
       <div class="img-show">
      <img src="assets/images/godrej.jpg">
     </div> 
     <div class="mt-2 title-col-company">
    
    </div>

  </div>
</div><div class="mb-2 col-md-2 col-sm-6 col-6">
     <div class="company-show-container sitesshow-container">
       <div class="img-show">
      <img src="assets/images/godrej.jpg">
     </div> 
     <div class="mt-2 title-col-company">
    
    </div>

  </div>
</div>
<div class="mb-2 col-md-2 col-sm-6 col-6">
     <div class="company-show-container sitesshow-container">
       <div class="img-show">
      <img src="assets/images/godrej.jpg">
     </div> 
     <div class="mt-2 title-col-company">
    
    </div>

  </div>
</div>
<div class="mb-2 col-md-2 col-sm-6 col-6">
     <div class="company-show-container sitesshow-container">
       <div class="img-show">
      <img src="assets/images/godrej.jpg">
     </div> 
     <div class="mt-2 title-col-company">
     
    </div>

  </div>
</div>
</div>

</section>


<section class="containerss Sites-details">
  <div class="title-sites">
    <h1> Agriculture News </h1>
    <p>Check out Latest Agriculture News, Agri Companies news, Government Agriculture News</p>
  </div>
  <div class="row">
  <?php  if(count($result) > 0){
                                    foreach($result as $row){ 
                            
                          ?>
    <div class="mb-4 col-md-4 col-sm-6 col-xs-12">
     <div class="sitesshow-container">
       <div class="img-show">
      <img src="assets/upload/<?php echo  $row['post_img']; ?>" height="200">
     </div> 
     <div class="mt-2 title-col">
     <a href="index.php?controller=post&function=post&slug=<?php echo $row['slug'] ?>"><h2><?php echo  $row['title']; ?></h2></a>
    </div>
    </div>
</div>
<?php  }}
    ?>
</section>
<!-- Footer -->
<?php 
include('component/footer.php');
?>